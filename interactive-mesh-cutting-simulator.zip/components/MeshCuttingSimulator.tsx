
import React, { useEffect, useRef, useState } from 'react';
import { PlayIcon, PauseIcon, RotateCcwIcon, ScissorsIcon, HandIcon } from './icons';

const MeshCuttingSimulator = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isSimulating, setIsSimulating] = useState(true);
  const [mode, setMode] = useState<'deform' | 'cut'>('deform');
  const [stats, setStats] = useState({ springs: 0, triangles: 0, particles: 0 });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    const config = {
      width: 800,
      height: 600,
      gravity: 0.4,
      damping: 0.99,
      stiffness: 0.6,
      tearThreshold: 3.5,
      pointRadius: 4,
      lineWidth: 1.5,
      constraintIterations: 5,
      grabRadius: 60,
      grabInfluence: 0.1,
    };

    class Particle {
      x: number;
      y: number;
      px: number;
      py: number;
      fixed: boolean;
      mass: number;

      constructor(x: number, y: number, fixed = false) {
        this.x = x;
        this.y = y;
        this.px = x;
        this.py = y;
        this.fixed = fixed;
        this.mass = 1;
      }

      update(dt: number) {
        if (this.fixed) return;
        
        const vx = (this.x - this.px) * config.damping;
        const vy = (this.y - this.py) * config.damping;
        
        this.px = this.x;
        this.py = this.y;
        
        this.x += vx;
        this.y += vy + config.gravity * dt;
        
        if (this.y > config.height - 5) {
          this.y = config.height - 5;
          this.py = this.y + vy * 0.3;
        }
        if (this.x < 5) {
          this.x = 5;
          this.px = this.x - vx * 0.3;
        }
        if (this.x > config.width - 5) {
          this.x = config.width - 5;
          this.px = this.x - vx * 0.3;
        }
      }
    }

    class Spring {
      p1: Particle;
      p2: Particle;
      restLength: number;
      active: boolean;
      maxLength: number;
      stiffness: number;

      constructor(p1: Particle, p2: Particle, restLength: number | null = null, stiffness?: number) {
        this.p1 = p1;
        this.p2 = p2;
        this.restLength = restLength || Math.hypot(p2.x - p1.x, p2.y - p1.y);
        this.active = true;
        this.maxLength = this.restLength * config.tearThreshold;
        this.stiffness = stiffness ?? config.stiffness;
      }

      solve() {
        if (!this.active) return false;

        const dx = this.p2.x - this.p1.x;
        const dy = this.p2.y - this.p1.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        
        if (dist > this.maxLength) {
          this.active = false;
          return false;
        }

        if (dist < 0.0001) return true;

        const diff = (this.restLength - dist) / dist;
        const offsetX = dx * diff * 0.5 * this.stiffness;
        const offsetY = dy * diff * 0.5 * this.stiffness;

        if (!this.p1.fixed) {
          this.p1.x -= offsetX;
          this.p1.y -= offsetY;
        }
        if (!this.p2.fixed) {
          this.p2.x += offsetX;
          this.p2.y += offsetY;
        }

        return true;
      }

      getStress() {
        const dx = this.p2.x - this.p1.x;
        const dy = this.p2.y - this.p1.y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        return Math.min((dist - this.restLength) / this.restLength, 2);
      }
    }

    class Triangle {
      p1: Particle;
      p2: Particle;
      p3: Particle;
      id: number;
      active: boolean;

      constructor(p1: Particle, p2: Particle, p3: Particle, id: number) {
        this.p1 = p1;
        this.p2 = p2;
        this.p3 = p3;
        this.id = id;
        this.active = true;
      }
    }

    class DeformableMesh {
      particles: Particle[];
      springs: Spring[];
      triangles: Triangle[];

      constructor() {
        this.particles = [];
        this.springs = [];
        this.triangles = [];
        this.createClothMesh();
        this.updateStats();
      }

      createClothMesh() {
        const rows = 20;
        const cols = 25;
        const spacing = 20;
        const offsetX = (config.width - (cols - 1) * spacing) / 2;
        const offsetY = 80;

        const particleGrid: Particle[][] = [];

        for (let i = 0; i < rows; i++) {
          particleGrid[i] = [];
          for (let j = 0; j < cols; j++) {
            const fixed = i === 0 && (j % 3 === 0 || j === cols - 1);
            const p = new Particle(
              offsetX + j * spacing,
              offsetY + i * spacing,
              fixed
            );
            this.particles.push(p);
            particleGrid[i][j] = p;
          }
        }

        for (let i = 0; i < rows; i++) {
          for (let j = 0; j < cols; j++) {
            if (j < cols - 1) {
              this.springs.push(new Spring(
                particleGrid[i][j],
                particleGrid[i][j + 1]
              ));
            }
            
            if (i < rows - 1) {
              this.springs.push(new Spring(
                particleGrid[i][j],
                particleGrid[i + 1][j]
              ));
            }

            if (i < rows - 1 && j < cols - 1) {
              this.springs.push(new Spring(
                particleGrid[i][j],
                particleGrid[i + 1][j + 1]
              ));
              this.springs.push(new Spring(
                particleGrid[i][j + 1],
                particleGrid[i + 1][j]
              ));
            }
          }
        }

        let triId = 0;
        for (let i = 0; i < rows - 1; i++) {
          for (let j = 0; j < cols - 1; j++) {
            const p1 = particleGrid[i][j];
            const p2 = particleGrid[i][j + 1];
            const p3 = particleGrid[i + 1][j];
            const p4 = particleGrid[i + 1][j + 1];
            
            this.triangles.push(new Triangle(p1, p2, p3, triId++));
            this.triangles.push(new Triangle(p2, p4, p3, triId++));
          }
        }
      }

      update(dt: number, mouseSpring: Spring | null = null) {
        for (const p of this.particles) {
          p.update(dt);
        }

        for (let iter = 0; iter < config.constraintIterations; iter++) {
          for (const spring of this.springs) {
            spring.solve();
          }
          if (mouseSpring) {
            mouseSpring.solve();
          }
        }

        if (mouseSpring) {
          const grabbedParticle = mouseSpring.p2;
          const mouseParticle = mouseSpring.p1;
          
          for (const p of this.particles) {
            if (p === grabbedParticle || p.fixed) continue;
  
            const dx = p.x - grabbedParticle.x;
            const dy = p.y - grabbedParticle.y;
            const dist = Math.sqrt(dx * dx + dy * dy);
  
            if (dist < config.grabRadius) {
              const influence = (1 - dist / config.grabRadius);
              const forceFactor = influence * config.grabInfluence;
  
              p.x += (mouseParticle.x - p.x) * forceFactor;
              p.y += (mouseParticle.y - p.y) * forceFactor;
            }
          }
        }
      }

      cut(x1: number, y1: number, x2: number, y2: number) {
        for (const spring of this.springs) {
          if (!spring.active) continue;
          
          if (this.lineIntersectsLine(
            x1, y1, x2, y2,
            spring.p1.x, spring.p1.y,
            spring.p2.x, spring.p2.y
          )) {
            spring.active = false;
          }
        }

        for (const tri of this.triangles) {
          if (!tri.active) continue;
          
          const edges = [
            [tri.p1, tri.p2],
            [tri.p2, tri.p3],
            [tri.p3, tri.p1]
          ];

          let intersections = 0;
          for (const [pa, pb] of edges) {
            if (this.lineIntersectsLine(x1, y1, x2, y2, pa.x, pa.y, pb.x, pb.y)) {
              intersections++;
            }
          }

          if (intersections >= 2) {
            tri.active = false;
          }
        }

        this.updateStats();
      }

      lineIntersectsLine(x1: number, y1: number, x2: number, y2: number, x3: number, y3: number, x4: number, y4: number) {
        const denom = (y4 - y3) * (x2 - x1) - (x4 - x3) * (y2 - y1);
        if (Math.abs(denom) < 0.00001) return false;

        const ua = ((x4 - x3) * (y1 - y3) - (y4 - y3) * (x1 - x3)) / denom;
        const ub = ((x2 - x1) * (y1 - y3) - (y2 - y1) * (x1 - x3)) / denom;

        return ua >= 0 && ua <= 1 && ub >= 0 && ub <= 1;
      }

      updateStats() {
        const activeTriangles = this.triangles.filter(t => t.active).length;
        const activeSprings = this.springs.filter(s => s.active).length;
        setStats({
          particles: this.particles.length,
          springs: activeSprings,
          triangles: activeTriangles
        });
      }

      render(ctx: CanvasRenderingContext2D, grabbedParticle: Particle | null = null, mouseX = 0, mouseY = 0) {
        ctx.clearRect(0, 0, config.width, config.height);

        for (const tri of this.triangles) {
          if (!tri.active) continue;
          
          ctx.beginPath();
          ctx.moveTo(tri.p1.x, tri.p1.y);
          ctx.lineTo(tri.p2.x, tri.p2.y);
          ctx.lineTo(tri.p3.x, tri.p3.y);
          ctx.closePath();
          
          const gradient = ctx.createLinearGradient(
            tri.p1.x, tri.p1.y,
            tri.p3.x, tri.p3.y
          );
          gradient.addColorStop(0, 'rgba(100, 150, 220, 0.7)');
          gradient.addColorStop(1, 'rgba(80, 120, 200, 0.7)');
          
          ctx.fillStyle = gradient;
          ctx.fill();
          
          ctx.strokeStyle = 'rgba(60, 90, 150, 0.4)';
          ctx.lineWidth = 0.5;
          ctx.stroke();
        }

        for (const spring of this.springs) {
          if (!spring.active) continue;
          
          const stress = spring.getStress();
          let color;
          
          if (stress > 1.5) {
            color = 'rgba(255, 50, 50, 0.9)';
          } else if (stress > 0.8) {
            color = `rgba(255, ${150 - stress * 100}, 50, 0.8)`;
          } else {
            color = 'rgba(80, 120, 180, 0.5)';
          }
          
          ctx.strokeStyle = color;
          ctx.lineWidth = stress > 0.8 ? 2 : 1;
          ctx.beginPath();
          ctx.moveTo(spring.p1.x, spring.p1.y);
          ctx.lineTo(spring.p2.x, spring.p2.y);
          ctx.stroke();
        }

        if (grabbedParticle) {
            ctx.beginPath();
            ctx.arc(mouseX, mouseY, config.grabRadius, 0, Math.PI * 2);
            const gradient = ctx.createRadialGradient(mouseX, mouseY, 10, mouseX, mouseY, config.grabRadius);
            gradient.addColorStop(0, 'rgba(255, 255, 100, 0.25)');
            gradient.addColorStop(1, 'rgba(255, 255, 100, 0)');
            ctx.fillStyle = gradient;
            ctx.fill();
            
            ctx.beginPath();
            ctx.arc(grabbedParticle.x, grabbedParticle.y, config.pointRadius + 8, 0, Math.PI * 2);
            ctx.strokeStyle = 'rgba(255, 255, 100, 0.9)';
            ctx.lineWidth = 3;
            ctx.stroke();
        }

        ctx.fillStyle = '#2d3748';
        for (const p of this.particles) {
          if (p.fixed) {
            ctx.beginPath();
            ctx.arc(p.x, p.y, config.pointRadius + 1, 0, Math.PI * 2);
            ctx.fill();
            
            ctx.strokeStyle = '#4a5568';
            ctx.lineWidth = 2;
            ctx.stroke();
          }
        }
      }
    }

    const mesh = new DeformableMesh();

    let mouseDown = false;
    let cutStartX = 0;
    let cutStartY = 0;
    let currentMouseX = 0;
    let currentMouseY = 0;

    let grabbedParticle: Particle | null = null;
    let mouseAttachmentSpring: Spring | null = null;
    const mouseParticle = new Particle(0, 0, true);

    const getMousePos = (e: MouseEvent) => {
      const rect = canvas.getBoundingClientRect();
      return {
        x: e.clientX - rect.left,
        y: e.clientY - rect.top
      };
    };

    const handleMouseDown = (e: MouseEvent) => {
      const pos = getMousePos(e);
      mouseDown = true;
      currentMouseX = pos.x;
      currentMouseY = pos.y;
      
      if (mode === 'deform') {
        let closestParticle: Particle | null = null;
        let min_dist_sq = 80 * 80;

        for (const p of mesh.particles) {
            const dx = p.x - pos.x;
            const dy = p.y - pos.y;
            const dist_sq = dx*dx + dy*dy;
            if (dist_sq < min_dist_sq) {
                min_dist_sq = dist_sq;
                closestParticle = p;
            }
        }
        if (closestParticle) {
            grabbedParticle = closestParticle;
            mouseParticle.x = pos.x;
            mouseParticle.y = pos.y;
            mouseAttachmentSpring = new Spring(mouseParticle, grabbedParticle, 0, 0.4);
        }

      } else { // cut mode
        cutStartX = pos.x;
        cutStartY = pos.y;
      }
    };

    const handleMouseMove = (e: MouseEvent) => {
      const pos = getMousePos(e);
      currentMouseX = pos.x;
      currentMouseY = pos.y;

      if (mouseDown && mode === 'deform' && mouseAttachmentSpring) {
        mouseParticle.x = pos.x;
        mouseParticle.y = pos.y;
      }
    };

    const handleMouseUp = (e: MouseEvent) => {
      if (mouseDown && mode === 'cut') {
        const pos = getMousePos(e);
        mesh.cut(cutStartX, cutStartY, pos.x, pos.y);
      }
      mouseDown = false;
      grabbedParticle = null;
      mouseAttachmentSpring = null;
    };

    canvas.addEventListener('mousedown', handleMouseDown);
    canvas.addEventListener('mousemove', handleMouseMove);
    canvas.addEventListener('mouseup', handleMouseUp);
    canvas.addEventListener('mouseleave', handleMouseUp);

    let lastTime = performance.now();
    let animationId: number;

    const animate = () => {
      const currentTime = performance.now();
      const deltaTime = Math.min((currentTime - lastTime) / 16.67, 2);
      lastTime = currentTime;

      if (isSimulating) {
        mesh.update(deltaTime, mouseAttachmentSpring);
      }

      ctx.fillStyle = '#0f172a';
      ctx.fillRect(0, 0, config.width, config.height);

      mesh.render(ctx, grabbedParticle, currentMouseX, currentMouseY);

      if (mouseDown && mode === 'cut') {
        ctx.save();
        ctx.strokeStyle = '#ef4444';
        ctx.lineWidth = 3;
        ctx.setLineDash([8, 4]);
        ctx.shadowColor = '#ef4444';
        ctx.shadowBlur = 10;
        ctx.beginPath();
        ctx.moveTo(cutStartX, cutStartY);
        ctx.lineTo(currentMouseX, currentMouseY);
        ctx.stroke();
        ctx.restore();
      }

      ctx.fillStyle = 'rgba(255, 255, 255, 0.95)';
      ctx.font = 'bold 18px system-ui, sans-serif';
      ctx.fillText(`Mode: ${mode === 'cut' ? 'CUTTING ✂️' : 'DEFORMING 👋'}`, 20, 35);
      
      ctx.font = '14px system-ui, sans-serif';
      ctx.fillStyle = 'rgba(255, 255, 255, 0.8)';
      ctx.fillText(
        mode === 'cut' ? 'Click & drag to slice through mesh' : 'Click & drag to grab and pull the mesh',
        20,
        60
      );

      animationId = requestAnimationFrame(animate);
    };

    animate();

    return () => {
      canvas.removeEventListener('mousedown', handleMouseDown);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseup', handleMouseUp);
      canvas.removeEventListener('mouseleave', handleMouseUp);
      if (animationId) {
        cancelAnimationFrame(animationId);
      }
    };
  }, [isSimulating, mode]);

  const handleReset = () => {
    // A simple way to reset the simulation state
    setIsSimulating(false);
    setTimeout(() => setIsSimulating(true), 10);
  };

  const toggleSimulation = () => {
    setIsSimulating(!isSimulating);
  };

  const toggleMode = () => {
    setMode(mode === 'cut' ? 'deform' : 'cut');
  };

  return (
    <div className="w-full min-h-screen bg-gradient-to-br from-slate-900 via-blue-900 to-slate-900 flex items-center justify-center p-4">
      <div className="bg-slate-800 rounded-2xl shadow-2xl p-4 sm:p-8 max-w-5xl w-full">
        <div className="text-center mb-6">
          <h1 className="text-3xl sm:text-4xl font-bold text-white mb-2">
            Real-Time Deformable Mesh Cutting Simulator
          </h1>
          <p className="text-slate-300 text-md sm:text-lg">
            Physics-based soft body simulation with dynamic topology modification
          </p>
        </div>
        
        <div className="bg-slate-900 rounded-xl p-2 mb-6 shadow-inner aspect-[4/3] w-full">
          <canvas
            ref={canvasRef}
            width={800}
            height={600}
            className="w-full h-full rounded-lg cursor-crosshair"
          />
        </div>

        <div className="grid grid-cols-3 gap-2 sm:gap-4 mb-6">
          <div className="bg-slate-700 rounded-lg p-3 sm:p-4 text-center">
            <div className="text-2xl sm:text-3xl font-bold text-blue-400">{stats.particles}</div>
            <div className="text-slate-300 text-xs sm:text-sm mt-1">Particles</div>
          </div>
          <div className="bg-slate-700 rounded-lg p-3 sm:p-4 text-center">
            <div className="text-2xl sm:text-3xl font-bold text-green-400">{stats.springs}</div>
            <div className="text-slate-300 text-xs sm:text-sm mt-1">Active Springs</div>
          </div>
          <div className="bg-slate-700 rounded-lg p-3 sm:p-4 text-center">
            <div className="text-2xl sm:text-3xl font-bold text-purple-400">{stats.triangles}</div>
            <div className="text-slate-300 text-xs sm:text-sm mt-1">Active Triangles</div>
          </div>
        </div>

        <div className="flex gap-2 sm:gap-4 justify-center items-center flex-wrap mb-6">
          <button
            onClick={toggleSimulation}
            className="flex items-center gap-2 sm:gap-3 px-4 py-3 sm:px-6 sm:py-4 bg-blue-600 hover:bg-blue-700 text-white rounded-xl font-bold transition-all transform hover:scale-105 shadow-lg text-sm sm:text-base"
          >
            {isSimulating ? <PauseIcon size={20} /> : <PlayIcon size={20} />}
            {isSimulating ? 'Pause' : 'Resume'}
          </button>

          <button
            onClick={toggleMode}
            className={`flex items-center gap-2 sm:gap-3 px-4 py-3 sm:px-6 sm:py-4 rounded-xl font-bold transition-all transform hover:scale-105 shadow-lg text-sm sm:text-base ${
              mode === 'cut' 
                ? 'bg-red-600 hover:bg-red-700 text-white' 
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
          >
            {mode === 'cut' ? <ScissorsIcon size={20} /> : <HandIcon size={20} />}
            {mode === 'cut' ? 'Cut Mode' : 'Deform Mode'}
          </button>

          <button
            onClick={handleReset}
            className="flex items-center gap-2 sm:gap-3 px-4 py-3 sm:px-6 sm:py-4 bg-slate-600 hover:bg-slate-700 text-white rounded-xl font-bold transition-all transform hover:scale-105 shadow-lg text-sm sm:text-base"
          >
            <RotateCcwIcon size={20} />
            Reset
          </button>
        </div>

        <div className="bg-slate-700 rounded-xl p-4 sm:p-6">
          <h3 className="text-white font-bold text-lg sm:text-xl mb-4 flex items-center gap-2">
            <span className="text-2xl">⚙️</span> Technical Features
          </h3>
          <div className="grid md:grid-cols-2 gap-4 text-sm sm:text-base">
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-blue-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Verlet Integration</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Position-based dynamics for stable simulation</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-green-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Mass-Spring System</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Structural and shear springs for realistic cloth</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-purple-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Dynamic Topology</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Real-time mesh cutting and restructuring</div>
                </div>
              </div>
            </div>
            <div className="space-y-2">
              <div className="flex items-start gap-2">
                <span className="text-yellow-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Stress Visualization</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Color-coded spring tension indicators</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-red-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Material Failure</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Automatic tearing at stress threshold</div>
                </div>
              </div>
              <div className="flex items-start gap-2">
                <span className="text-pink-400 mt-1">▸</span>
                <div>
                  <div className="text-white font-semibold">Interactive Forces</div>
                  <div className="text-slate-400 text-xs sm:text-sm">Soft-body grabbing with a realistic area of influence</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MeshCuttingSimulator;
