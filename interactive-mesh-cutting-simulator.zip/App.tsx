
import React from 'react';
import MeshCuttingSimulator from './components/MeshCuttingSimulator';

const App: React.FC = () => {
  return (
    <div className="App">
      <MeshCuttingSimulator />
    </div>
  );
};

export default App;
